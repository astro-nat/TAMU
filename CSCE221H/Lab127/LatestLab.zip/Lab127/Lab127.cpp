// Lab127.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <cmath>

using namespace std;

template <class T, int n>
class Point
{
private:
	T myarray[n];
public:
	T& operator[] (int i) { return myarray[i]; }
	int size() { return n; };
	
	Point (T myarray[n]) {};
};

template <class D>
int euclid(D& p1, D& p2)
{
	int distance;
	int sum;

	for (int i = 0; i < p1.size(); i++)
	{
		distance = 0;
		distance = sqrt(pow(p1[i] + p2[i], 2));
		cout << "The distance between points " << p1[i] << " and " << p2[i] << " is " << distance << "." << endl;
	}
	return 0;
};

int main()
{
	double arr1[3] = { 1, 2, 3 };
	double arr2[3] = { 2, 4, 6 };
	Point <double, 3> p1(arr1);
	Point <double, 3> p2(arr2);

	euclid(p1,p2);

	int arr3[2] = { 1, 2 };
	int arr4[2] = { 3, 4 };
	Point <int, 2> p3(arr3);
	Point <int, 2> p4(arr4);
	
	euclid(p3, p4);
	
	int temp;
	cin >> temp; 
}