// Lab127.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <cmath>

using namespace std;

template <class T, int n>
class Point
{
private:
	T myarray[n];
public:
	T& operator[] (int i) { return myarray[i]; }
	int size() { return n; };
	
	Point (T myarray[n]) {};
	
	int euclid()
	{
		int distance;
		int sum;

		for (int i = 0; i < n; i++)
		{
			sum = (myarray[i] + myarray[i + 1]);
			distance = sqrt(sum);
			cout << "The distance between points " << myarray[i] << " and " << myarray[i + 1] << " is " << distance << "." << endl;
		}
		return 0;
	};
};



int main()
{
	double arr1[3] = { 1, 2, 3 };
	double arr2[3] = { 2, 4, 6 };
	Point <double, 3> p1(arr1);
	Point <double, 3> p2(arr2);

	p1.euclid();
	p2.euclid();

	int arr3[2] = { 1, 2 };
	int arr4[2] = { 3, 4 };
	Point <int, 2> p3(arr3);
	Point <int, 2> p4(arr4);
	
	p3.euclid();
	p4.euclid();
	
	int temp;
	cin >> temp; 
}