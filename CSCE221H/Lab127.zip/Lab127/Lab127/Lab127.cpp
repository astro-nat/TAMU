// Lab127.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

using namespace std;

template <class T, int n>
class Point
{
public:
	T myarray[n];
	T& operator[] (int i) { return myarray[i]; }
	int size() { return n; };
	Point(T myarray) : myarray(myarray) {};
};

template <class D>
int euclid(D p1, D p2)
{
	int distance;
	int sum;

	for (int i = 0; i < p1.size(); i++)
	{
		sum = (p1[i] + p2[i]);
		distance = (sum ^ (1 / 2));
		cout << "The distances between these two points are" << distance << endl;
	}
}

int main()
{
	double num1[3]; 
	num1[0] = 1; num1[1] = 2; num1[2] = 3;
	double num2[3];
	Point < double, 3 > p1(num1);
	Point < double, 3 > p2(num2);

	euclid(p1, p2);

	int num3 = (1, 2, 3);
	int num4 = (2, 3, 4);
	Point<int, 2> p3(num3);
	Point<int, 2> p4(num4);

	euclid(p3, p4);
	
	int temp;
	cin >> temp; 
}