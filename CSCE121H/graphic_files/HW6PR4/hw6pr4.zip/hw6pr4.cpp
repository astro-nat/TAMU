// http://gamedev.stackexchange.com/questions/1692/what-is-a-simple-algorithm-for-calculating-evenly-distributed-points-on-an-ellip
// http://stackoverflow.com/questions/24220750/creating-a-hexagon-class

#include "Graph.h"
#include "Simple_window.h"
#include "std_lib_facilities_4.h"
#include <cmath>

using namespace Graph_lib;

void display_window()
{
	Point tl {100,100};
    Simple_window win {tl,600,600,"Your Shape"};
	win.wait_for_button();
}

struct Regular_polygon : Shape 
{
	Regular_polygon(Point p, int s, int d):center(p),points(s),distance(d)
		{ add(Point(p)); }; // beginning or end of class?

	void draw_lines() const;
	void setdistance(int temp) {distance = temp;}; // distance from center to a point
	void setcenter(int temp1,int temp2)
		{
			if(temp1 < 0 || temp1 > 600 || temp2 < 0 || temp2 > 600){
				error("One or more of your values is out of bounds. Try again.");
				setcenter(temp1,temp2);
			}
			else
			{
				x = temp1;
				y = temp2;
				Point center(Point{x,y}) // center of shape. Must be  within 600,600
			}
		}
	void setpoints(int temp)
	{
		if (temp <= 2)
		{
			error("Invalid number of sides. Try again.");
			setpoints(int temp);
		}
		else // found this section of code from one of links at top. Will it work?
		{
			int points = temp;
		
			// create imaginary circle around center where points are distributed evenly
			int angleIncrement = 360 / temp;
			int circleRadius = distance;
			for (int i = 0; i < temp; i++)
			{
				int p = new Point();
				p.x = (circleRadius * Math.cos((angleIncrement * i) * (Math.PI / 180)));
				p.y = (circleRadius * Math.sin((angleIncrement * i) * (Math.PI / 180)));
			}
		}	
	}
private:
	int x; // x value of center
	int y; // y value of center
	int points; // number of points. Should equal number of sides
	int distance; // distance from center to points
};

int main()
{
	try
	{
		Regular_polygon poly;
		int input1;
		int input2;
		
		cout << "Where do you want the center of your shape?" << endl;
		cin >> poly.setcenter(input1,input2);
				
		cout << "How many sides do you want?" << endl;
		cin >> poly.setpoints(input1);
		
		cout << "How big do you want your shape? Enter a number between 1 and 600." << endl;
		cin >> poly.setdistance(input1);
		
		display_window();
		poly(Point center(x,y), int sides, int distance); //creates polygon based on user's preferences
		void draw_line();
	}
	catch(exception& e)
	{
		//some code here
		return 1;
	}
	catch(...)
	{
		//some code here
		return 2;
	}
}

