For this assignment, I used a Linux environment in a Macbook Terminal to compile, run, and test. I used text editor XCode to edit code.

To compile:

	g++ -std=c++11 NCluck_IndividualAssignment.cpp -o main

To run: 

	./main
